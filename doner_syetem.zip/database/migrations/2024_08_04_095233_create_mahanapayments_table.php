<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mahanapayments', function (Blueprint $table) {
            $table->id();
            $table->string('recept_no');
            $table->string('amount')->nullable();
            $table->string('payment_month');
            $table->string('payment_date');
            $table->unsignedBigInteger('mahanakifalats_id');
            $table->foreign('mahanakifalats_id')->references('id')->on('mahanakifalats');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mahanapayments');
    }
};
