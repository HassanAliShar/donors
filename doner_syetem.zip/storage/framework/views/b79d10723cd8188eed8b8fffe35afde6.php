
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- slimscroll js -->
    <script type="text/javascript" src="<?php echo e(url('frontend/js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
 
    <!-- menu js -->
    <script src="<?php echo e(url('frontend/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(url('frontend/js/vertical-layout.min.js')); ?>"></script>
    <!-- custom js -->
    <script  src="<?php echo e(url('frontend/pages/dashboard/custom-dashboard.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('frontend/js/script.js')); ?>" type="text/javascript" ></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\nts_doner\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>